<?php
// SERIAL: MGH-PUB-IDX-005

session_start();

// توجيه تلقائي إذا كان مسجلاً للدخول
if (isset($_SESSION['user_id']) && isset($_SESSION['role'])) {
    if ($_SESSION['role'] === 'admin') {
        header("Location: ../admin/index.php");
    } else {
        header("Location: ../user/index.php");
    }
    exit;
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mugofhug - Ultimate Study Engine</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', system-ui, sans-serif; background: linear-gradient(135deg, #F8FAFC 0%, #E2E8F0 100%); display: flex; justify-content: center; align-items: center; min-height: 100vh; text-align: center; color: #0F172A; }
        .hero { max-width: 600px; padding: 2rem; }
        h1 { font-size: 3rem; color: #4338CA; margin-bottom: 1rem; font-weight: 800; letter-spacing: -1px; }
        p { font-size: 1.2rem; color: #475569; margin-bottom: 2rem; line-height: 1.6; }
        .btn { display: inline-block; padding: 1rem 2rem; background-color: #4338CA; color: white; text-decoration: none; border-radius: 8px; font-weight: bold; font-size: 1.1rem; transition: 0.3s; box-shadow: 0 4px 6px rgba(67, 56, 202, 0.2); }
        .btn:hover { background-color: #3730A3; transform: translateY(-2px); }
    </style>
</head>
<body>
    <div class="hero">
        <h1>Mugofhug AI</h1>
        <p>المنصة الهندسية المتطورة لتحويل الملاحظات المعقدة إلى واجهات دراسية تفاعلية بلمسة زر واحدة باستخدام أحدث تقنيات الذكاء الاصطناعي.</p>
        <a href="login.php" class="btn">تسجيل الدخول للنظام</a>
    </div>
</body>
</html>