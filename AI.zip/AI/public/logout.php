<?php
// SERIAL: MGH-PUB-OUT-010
session_start();
session_unset();
session_destroy();
header("Location: login.php");
exit;
?>