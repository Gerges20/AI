<?php
// SERIAL: MGH-PUB-LOG-004

require_once __DIR__ . '/../core/security.php';

$error = '';

// إذا كان المستخدم مسجلاً بالفعل، قم بتوجيهه بناءً على دوره
if (isset($_SESSION['user_id']) && isset($_SESSION['role'])) {
    if ($_SESSION['role'] === 'admin') {
        header("Location: ../admin/index.php");
        exit;
    } else {
        header("Location: ../user/index.php");
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf_token = $_POST['csrf_token'] ?? '';
    
    // التحقق الصارم من توكن الحماية
    if (!isset($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $csrf_token)) {
        die("Security Violation: Invalid Token.");
    }

    $username = sanitizeInput($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($username) || empty($password)) {
        $error = "يرجى إدخال اسم المستخدم وكلمة المرور.";
    } else {
        $stmt = $pdo->prepare("SELECT id, password_hash, role, status FROM users_ai WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password_hash'])) {
            // التحقق من حالة الحساب قبل السماح بالدخول
            if ($user['status'] === 'inactive') {
                $error = "حسابك قيد المراجعة. يرجى انتظار تفعيل الإدارة.";
            } elseif ($user['status'] === 'blocked') {
                $error = "تم حظر هذا الحساب لمخالفته شروط الاستخدام.";
            } else {
                // الحساب نشط: تجديد معرف الجلسة لمنع هجمات Session Fixation
                session_regenerate_id(true);
                
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['role'] = $user['role'];
                
                if ($user['role'] === 'admin') {
                    header("Location: ../admin/index.php");
                } else {
                    header("Location: ../user/index.php");
                }
                exit;
            }
        } else {
            // رسالة خطأ موحدة لمنع تخمين الحسابات
            $error = "بيانات الدخول غير صحيحة.";
        }
    }
}

$csrfToken = generateCSRFToken();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تسجيل الدخول - Mugofhug</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', system-ui, sans-serif; background-color: #F8FAFC; display: flex; justify-content: center; align-items: center; min-height: 100vh; }
        .auth-container { background: #FFFFFF; padding: 2.5rem; border-radius: 12px; box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1); width: 100%; max-width: 400px; }
        h2 { text-align: center; color: #4338CA; margin-bottom: 1.5rem; }
        .form-group { margin-bottom: 1rem; }
        label { display: block; margin-bottom: 0.5rem; font-weight: 600; font-size: 0.9rem; color: #0F172A; }
        input { width: 100%; padding: 0.75rem; border: 1px solid rgba(226, 232, 240, 0.9); border-radius: 6px; outline: none; transition: 0.3s; }
        input:focus { border-color: #4338CA; box-shadow: 0 0 0 3px rgba(67, 56, 202, 0.1); }
        button { width: 100%; padding: 0.85rem; background-color: #4338CA; color: white; border: none; border-radius: 6px; font-weight: bold; cursor: pointer; margin-top: 1rem; transition: 0.3s; }
        button:hover { background-color: #3730A3; }
        .alert { padding: 1rem; border-radius: 6px; margin-bottom: 1rem; text-align: center; }
        .error { background-color: #FEE2E2; color: #991B1B; border: 1px solid #F87171; }
        .register-link { display: block; text-align: center; margin-top: 1rem; font-size: 0.9rem; color: #4338CA; text-decoration: none; font-weight: 600; }
    </style>
</head>
<body>
    <div class="auth-container">
        <h2>تسجيل الدخول - Mugofhug</h2>
        
        <?php if ($error): ?>
            <div class="alert error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
            <div class="form-group">
                <label>اسم المستخدم</label>
                <input type="text" name="username" required autocomplete="username">
            </div>
            <div class="form-group">
                <label>كلمة المرور</label>
                <input type="password" name="password" required autocomplete="current-password">
            </div>
            <button type="submit">دخول إلى النظام</button>
        </form>
        <a href="register.php" class="register-link">طلب انضمام للنظام (حساب جديد)</a>
    </div>
</body>
</html>