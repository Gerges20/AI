<?php
// SERIAL: MGH-PUB-REG-006

require_once __DIR__ . '/../core/security.php';

// إذا كان المستخدم مسجلاً للدخول بالفعل، يتم توجيهه للوحة التحكم
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf_token = $_POST['csrf_token'] ?? '';
    verifyCSRFToken($csrf_token); // التحقق الصارم من التوكن لمنع هجمات CSRF

    $name = sanitizeInput($_POST['name'] ?? '');
    $username = sanitizeInput($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $password_confirm = $_POST['password_confirm'] ?? '';

    if (empty($name) || empty($username) || empty($password)) {
        $error = "جميع الحقول مطلوبة.";
    } elseif ($password !== $password_confirm) {
        $error = "كلمات المرور غير متطابقة.";
    } elseif (strlen($password) < 8) {
        $error = "كلمة المرور يجب أن تكون 8 أحرف على الأقل.";
    } else {
        // التحقق من عدم تكرار اسم المستخدم
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM users_ai WHERE username = ?");
        $stmt->execute([$username]);
        if ($stmt->fetchColumn() > 0) {
            $error = "اسم المستخدم مسجل مسبقاً، يرجى اختيار اسم آخر.";
        } else {
            $password_hash = password_hash($password, PASSWORD_BCRYPT);
            // إدراج الحساب الجديد بحالة 'inactive' وصلاحية 'user' كإجراء أمني صارم
            $insertStmt = $pdo->prepare("INSERT INTO users_ai (name, username, password_hash, role, status) VALUES (?, ?, ?, 'user', 'inactive')");
            if ($insertStmt->execute([$name, $username, $password_hash])) {
                $success = "تم إرسال طلب الانضمام بنجاح. يرجى انتظار تفعيل الحساب من قبل الإدارة.";
            } else {
                $error = "حدث خطأ داخلي أثناء إنشاء الحساب.";
            }
        }
    }
}

$csrfToken = generateCSRFToken();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إنشاء حساب - Mugofhug</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', system-ui, sans-serif; background-color: #F8FAFC; display: flex; justify-content: center; align-items: center; min-height: 100vh; }
        .auth-container { background: #FFFFFF; padding: 2.5rem; border-radius: 12px; box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1); width: 100%; max-width: 400px; border: 1px solid rgba(226, 232, 240, 0.9); }
        h2 { text-align: center; color: #4338CA; margin-bottom: 1.5rem; font-weight: 800; }
        .form-group { margin-bottom: 1rem; }
        label { display: block; margin-bottom: 0.5rem; font-weight: 600; font-size: 0.9rem; color: #0F172A; }
        input { width: 100%; padding: 0.75rem; border: 1px solid rgba(226, 232, 240, 0.9); border-radius: 6px; outline: none; transition: 0.3s; font-size: 1rem; }
        input:focus { border-color: #4338CA; box-shadow: 0 0 0 3px rgba(67, 56, 202, 0.1); }
        button { width: 100%; padding: 0.85rem; background-color: #4338CA; color: white; border: none; border-radius: 6px; font-weight: bold; font-size: 1rem; cursor: pointer; margin-top: 1rem; transition: 0.3s; }
        button:hover { background-color: #3730A3; }
        .alert { padding: 1rem; border-radius: 6px; margin-bottom: 1.5rem; text-align: center; font-weight: 600; font-size: 0.95rem; }
        .error { background-color: #FEE2E2; color: #991B1B; border: 1px solid #F87171; }
        .success { background-color: #D1FAE5; color: #065F46; border: 1px solid #34D399; }
        .login-link { display: block; text-align: center; margin-top: 1.2rem; font-size: 0.9rem; color: #4338CA; text-decoration: none; font-weight: 600; transition: 0.2s; }
        .login-link:hover { color: #3730A3; text-decoration: underline; }
    </style>
</head>
<body>
    <div class="auth-container">
        <h2>Mugofhug Join Request</h2>
        
        <?php if ($error): ?>
            <div class="alert error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <?php if (!$success): ?>
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
            <div class="form-group">
                <label>الاسم الكامل</label>
                <input type="text" name="name" required autocomplete="name">
            </div>
            <div class="form-group">
                <label>اسم المستخدم (يستخدم للدخول)</label>
                <input type="text" name="username" required autocomplete="username">
            </div>
            <div class="form-group">
                <label>كلمة المرور</label>
                <input type="password" name="password" required autocomplete="new-password">
            </div>
            <div class="form-group">
                <label>تأكيد كلمة المرور</label>
                <input type="password" name="password_confirm" required autocomplete="new-password">
            </div>
            <button type="submit">إرسال طلب الانضمام</button>
        </form>
        <?php endif; ?>
        
        <a href="login.php" class="login-link">لديك حساب مفعل؟ تسجيل الدخول</a>
    </div>
</body>
</html>