<?php
// SERIAL: MGH-ADM-USR-009

require_once __DIR__ . '/../core/security.php';
$adminData = enforceUserSecurity($pdo, 'admin');

$message = '';
$error = '';

// معالجة طلبات الإدارة (POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCSRFToken($_POST['csrf_token'] ?? '');
    $action = $_POST['action'] ?? '';
    $target_id = (int)($_POST['user_id'] ?? 0);

    // حماية إضافية لمنع الأدمن من حذف أو حظر نفسه بالخطأ
    if ($target_id === $adminData['id'] && in_array($action, ['block', 'delete'])) {
        $error = "لا يمكنك تنفيذ هذا الإجراء على حسابك الشخصي.";
    } elseif ($target_id > 0) {
        try {
            if ($action === 'activate') {
                $stmt = $pdo->prepare("UPDATE users_ai SET status = 'active' WHERE id = ?");
                $stmt->execute([$target_id]);
                $message = "تم تفعيل الحساب بنجاح.";
            } elseif ($action === 'block') {
                $stmt = $pdo->prepare("UPDATE users_ai SET status = 'blocked' WHERE id = ?");
                $stmt->execute([$target_id]);
                $message = "تم حظر الحساب بنجاح.";
            } elseif ($action === 'delete') {
                $stmt = $pdo->prepare("DELETE FROM users_ai WHERE id = ?");
                $stmt->execute([$target_id]);
                $message = "تم حذف الحساب نهائياً.";
            } elseif ($action === 'change_password') {
                $new_password = $_POST['new_password'] ?? '';
                if (strlen($new_password) < 8) {
                    $error = "كلمة المرور الجديدة يجب أن تكون 8 أحرف على الأقل.";
                } else {
                    $hash = password_hash($new_password, PASSWORD_BCRYPT);
                    $stmt = $pdo->prepare("UPDATE users_ai SET password_hash = ? WHERE id = ?");
                    $stmt->execute([$hash, $target_id]);
                    $message = "تم تغيير كلمة المرور للمستخدم بنجاح (مخفية أمنياً).";
                }
            }
            
            // تسجيل الحدث في نظام المراقبة (Audit Log)
            if (empty($error)) {
                $logStmt = $pdo->prepare("INSERT INTO audit_logs_ai (admin_id, action_type, target_user_id, ip_address) VALUES (?, ?, ?, ?)");
                $logStmt->execute([$adminData['id'], $action, $target_id, $_SERVER['REMOTE_ADDR']]);
            }
        } catch (PDOException $e) {
            $error = "حدث خطأ أثناء تنفيذ الإجراء.";
            error_log("User Manager Error: " . $e->getMessage());
        }
    }
}

// جلب قائمة المستخدمين
$users = $pdo->query("SELECT id, name, username, role, status, created_at FROM users_ai ORDER BY created_at DESC")->fetchAll();
$csrfToken = generateCSRFToken();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة المستخدمين - Mugofhug Admin</title>
    <style>
        /* تم استيراد التنسيقات الأساسية للاختصار، مشابهة لـ index.php */
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', system-ui, sans-serif; background-color: #F8FAFC; color: #0F172A; display: flex; }
        .sidebar { width: 250px; background-color: #1E293B; color: white; min-height: 100vh; padding: 2rem 1rem; }
        .sidebar h2 { color: #818CF8; margin-bottom: 2rem; text-align: center; font-size: 1.5rem; }
        .sidebar a { display: block; color: #CBD5E1; text-decoration: none; padding: 0.75rem 1rem; margin-bottom: 0.5rem; border-radius: 6px; transition: 0.3s; }
        .sidebar a:hover, .sidebar a.active { background-color: #334155; color: white; }
        .main-content { flex: 1; padding: 2rem; overflow-x: auto; }
        h1 { margin-bottom: 1.5rem; color: #1E293B; }
        .alert { padding: 1rem; border-radius: 6px; margin-bottom: 1.5rem; }
        .alert.success { background-color: #D1FAE5; color: #065F46; border: 1px solid #34D399; }
        .alert.error { background-color: #FEE2E2; color: #991B1B; border: 1px solid #F87171; }
        
        table { width: 100%; background: white; border-collapse: collapse; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        th, td { padding: 1rem; text-align: right; border-bottom: 1px solid #E2E8F0; }
        th { background-color: #F1F5F9; font-weight: 600; color: #475569; }
        .status-badge { padding: 0.25rem 0.75rem; border-radius: 999px; font-size: 0.85rem; font-weight: bold; }
        .st-active { background-color: #D1FAE5; color: #065F46; }
        .st-inactive { background-color: #FEF3C7; color: #92400E; }
        .st-blocked { background-color: #FEE2E2; color: #991B1B; }
        
        .action-form { display: inline-block; margin-left: 0.5rem; }
        button { padding: 0.4rem 0.8rem; border: none; border-radius: 4px; cursor: pointer; font-size: 0.85rem; font-weight: bold; color: white; transition: 0.2s; }
        .btn-activate { background-color: #10B981; }
        .btn-activate:hover { background-color: #059669; }
        .btn-block { background-color: #F59E0B; }
        .btn-delete { background-color: #EF4444; }
        
        /* تصميم حقل تغيير الباسورد */
        .pwd-form { display: flex; gap: 0.5rem; margin-top: 0.5rem; }
        .pwd-form input { padding: 0.4rem; border: 1px solid #CBD5E1; border-radius: 4px; font-size: 0.85rem; outline: none; }
        .btn-pwd { background-color: #4338CA; }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>Mugofhug AI</h2>
        <a href="index.php">لوحة القيادة</a>
        <a href="users_manager.php" class="active">إدارة المستخدمين</a>
        <a href="prompts_manager.php">إعدادات الذكاء الاصطناعي</a>
    </div>
    
    <div class="main-content">
        <h1>إدارة المستخدمين والصلاحيات</h1>
        
        <?php if ($message): ?><div class="alert success"><?php echo htmlspecialchars($message); ?></div><?php endif; ?>
        <?php if ($error): ?><div class="alert error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

        <table>
            <thead>
                <tr>
                    <th>الاسم</th>
                    <th>اسم المستخدم</th>
                    <th>الدور</th>
                    <th>الحالة</th>
                    <th>تاريخ التسجيل</th>
                    <th>الإجراءات الأمنية</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $u): ?>
                <tr>
                    <td><?php echo htmlspecialchars($u['name']); ?></td>
                    <td><?php echo htmlspecialchars($u['username']); ?></td>
                    <td><?php echo htmlspecialchars($u['role']); ?></td>
                    <td>
                        <span class="status-badge st-<?php echo htmlspecialchars($u['status']); ?>">
                            <?php echo htmlspecialchars(strtoupper($u['status'])); ?>
                        </span>
                    </td>
                    <td><?php echo htmlspecialchars($u['created_at']); ?></td>
                    <td>
                        <?php if ($u['status'] !== 'active'): ?>
                        <form method="POST" class="action-form">
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
                            <input type="hidden" name="user_id" value="<?php echo $u['id']; ?>">
                            <input type="hidden" name="action" value="activate">
                            <button type="submit" class="btn-activate">تفعيل</button>
                        </form>
                        <?php endif; ?>
                        
                        <?php if ($u['status'] !== 'blocked' && $u['id'] !== $adminData['id']): ?>
                        <form method="POST" class="action-form">
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
                            <input type="hidden" name="user_id" value="<?php echo $u['id']; ?>">
                            <input type="hidden" name="action" value="block">
                            <button type="submit" class="btn-block" onclick="return confirm('هل أنت متأكد من حظر هذا المستخدم؟');">حظر</button>
                        </form>
                        <?php endif; ?>

                        <?php if ($u['id'] !== $adminData['id']): ?>
                        <form method="POST" class="action-form">
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
                            <input type="hidden" name="user_id" value="<?php echo $u['id']; ?>">
                            <input type="hidden" name="action" value="delete">
                            <button type="submit" class="btn-delete" onclick="return confirm('تحذير: هذا سيحذف المستخدم وكل ملفاته نهائياً. تأكيد؟');">حذف نهائي</button>
                        </form>
                        <?php endif; ?>

                        <form method="POST" class="pwd-form" onsubmit="return confirm('هل تريد إجبار تغيير كلمة المرور لهذا الحساب؟');">
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
                            <input type="hidden" name="user_id" value="<?php echo $u['id']; ?>">
                            <input type="hidden" name="action" value="change_password">
                            <input type="password" name="new_password" placeholder="كلمة مرور جديدة" required minlength="8">
                            <button type="submit" class="btn-pwd">تغيير السر</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>