<?php
// SERIAL: MGH-ADM-EDT-015

require_once __DIR__ . '/../core/security.php';
$adminData = enforceUserSecurity($pdo, 'admin');

$message = '';
$error = '';
$file_id = isset($_GET['file_id']) ? (int)$_GET['file_id'] : 0;

// معالجة حفظ الكود المعدل
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'save_code') {
    verifyCSRFToken($_POST['csrf_token'] ?? '');
    $page_id = (int)$_POST['page_id'];
    $updated_html = $_POST['generated_html'] ?? '';

    try {
        $stmt = $pdo->prepare("UPDATE pages_ai SET generated_html = ? WHERE id = ?");
        $stmt->execute([$updated_html, $page_id]);
        $message = "تم حفظ وتحديث الكود بنجاح.";
    } catch (PDOException $e) {
        $error = "حدث خطأ أثناء حفظ الكود.";
    }
}

// إذا تم اختيار ملف للتعديل
$editMode = false;
$pageData = null;

if ($file_id > 0) {
    $editMode = true;
    $stmt = $pdo->prepare("SELECT p.id as page_id, p.generated_html, f.original_file_path, u.username 
                           FROM pages_ai p 
                           JOIN files_ai f ON p.file_id = f.id 
                           JOIN users_ai u ON f.user_id = u.id 
                           WHERE f.id = ? LIMIT 1");
    $stmt->execute([$file_id]);
    $pageData = $stmt->fetch();
    
    if (!$pageData) {
        $error = "لم يتم العثور على صفحات مرتبطة بهذا الملف، ربما لم تكتمل المعالجة بعد.";
        $editMode = false;
    }
}

// جلب قائمة الملفات المكتملة لعرضها في الجدول
$stmtList = $pdo->query("
    SELECT f.id, f.original_file_path, u.username, f.created_at 
    FROM files_ai f 
    JOIN users_ai u ON f.user_id = u.id 
    WHERE f.processing_status = 'completed' 
    ORDER BY f.created_at DESC
");
$completedFiles = $stmtList->fetchAll();
$csrfToken = generateCSRFToken();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>محرر الملفات - Mugofhug Admin</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', system-ui, sans-serif; background-color: #F8FAFC; color: #0F172A; display: flex; min-height: 100vh; }
        .sidebar { width: 250px; background-color: #1E293B; color: white; padding: 2rem 1rem; flex-shrink: 0; }
        .sidebar h2 { color: #818CF8; margin-bottom: 2rem; text-align: center; }
        .sidebar a { display: block; color: #CBD5E1; text-decoration: none; padding: 0.75rem 1rem; margin-bottom: 0.5rem; border-radius: 6px; transition: 0.3s; }
        .sidebar a:hover, .sidebar a.active { background-color: #334155; color: white; }
        .main-content { flex: 1; padding: 2rem; overflow-y: auto; }
        h1 { margin-bottom: 1.5rem; color: #1E293B; }
        
        .alert { padding: 1rem; border-radius: 6px; margin-bottom: 1.5rem; font-weight: bold; }
        .alert.success { background-color: #D1FAE5; color: #065F46; border: 1px solid #34D399; }
        .alert.error { background-color: #FEE2E2; color: #991B1B; border: 1px solid #F87171; }
        
        table { width: 100%; background: white; border-collapse: collapse; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); margin-bottom: 2rem; }
        th, td { padding: 1rem; text-align: right; border-bottom: 1px solid #E2E8F0; }
        th { background-color: #F1F5F9; font-weight: 600; color: #475569; }
        .btn-edit { background-color: #4338CA; color: white; padding: 0.4rem 1rem; text-decoration: none; border-radius: 4px; font-size: 0.85rem; font-weight: bold; }
        
        /* تصميم المحرر */
        .editor-container { background: #1E1E1E; padding: 1rem; border-radius: 8px; box-shadow: 0 10px 15px -3px rgba(0,0,0,0.2); }
        .editor-header { display: flex; justify-content: space-between; align-items: center; color: white; margin-bottom: 1rem; }
        textarea.code-area { width: 100%; height: 60vh; background: #2D2D2D; color: #D4D4D4; font-family: 'Courier New', Courier, monospace; font-size: 14px; padding: 1rem; border: 1px solid #444; border-radius: 4px; outline: none; resize: vertical; line-height: 1.5; direction: ltr; text-align: left; }
        textarea.code-area:focus { border-color: #818CF8; }
        .btn-save { background-color: #10B981; color: white; border: none; padding: 0.75rem 2rem; border-radius: 4px; font-weight: bold; cursor: pointer; transition: 0.2s; font-size: 1rem; }
        .btn-save:hover { background-color: #059669; }
        .btn-back { background-color: #64748B; color: white; text-decoration: none; padding: 0.75rem 1.5rem; border-radius: 4px; margin-left: 1rem; font-weight: bold; }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>Mugofhug AI</h2>
        <a href="index.php">لوحة القيادة</a>
        <a href="users_manager.php">إدارة المستخدمين</a>
        <a href="prompts_manager.php">إعدادات الذكاء الاصطناعي</a>
        <a href="system_logs.php">سجلات التدقيق (Logs)</a>
        <a href="code_editor.php" class="active">محرر الأكواد للملفات</a>
    </div>
    
    <div class="main-content">
        <h1>محرر الأكواد (Code Override)</h1>
        
        <?php if ($message): ?><div class="alert success"><?php echo htmlspecialchars($message); ?></div><?php endif; ?>
        <?php if ($error): ?><div class="alert error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

        <?php if ($editMode && $pageData): ?>
            <div class="editor-container">
                <div class="editor-header">
                    <div>
                        <strong>صاحب الملف:</strong> <?php echo htmlspecialchars($pageData['username']); ?> | 
                        <strong>الملف الأصلي:</strong> <?php echo htmlspecialchars($pageData['original_file_path']); ?>
                    </div>
                    <div>
                        <a href="code_editor.php" class="btn-back">عودة للقائمة</a>
                    </div>
                </div>
                
                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
                    <input type="hidden" name="action" value="save_code">
                    <input type="hidden" name="page_id" value="<?php echo $pageData['page_id']; ?>">
                    
                    <textarea name="generated_html" class="code-area" spellcheck="false"><?php echo htmlspecialchars($pageData['generated_html']); ?></textarea>
                    
                    <div style="margin-top: 1rem; text-align: left;" dir="ltr">
                        <button type="submit" class="btn-save">💾 Save Changes</button>
                    </div>
                </form>
            </div>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>رقم الملف</th>
                        <th>اسم المستخدم</th>
                        <th>مسار الملف الأصلي</th>
                        <th>تاريخ المعالجة</th>
                        <th>الإجراء</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($completedFiles as $file): ?>
                    <tr>
                        <td>#<?php echo $file['id']; ?></td>
                        <td><strong><?php echo htmlspecialchars($file['username']); ?></strong></td>
                        <td dir="ltr" style="text-align: right;"><code><?php echo htmlspecialchars($file['original_file_path']); ?></code></td>
                        <td dir="ltr" style="text-align: right;"><?php echo htmlspecialchars($file['created_at']); ?></td>
                        <td>
                            <a href="?file_id=<?php echo $file['id']; ?>" class="btn-edit">تعديل كود HTML</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($completedFiles)): ?>
                    <tr><td colspan="5" style="text-align: center;">لا توجد ملفات مكتملة المعالجة حتى الآن.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</body>
</html>