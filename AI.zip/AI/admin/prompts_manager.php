<?php
// SERIAL: MGH-ADM-PRM-011

require_once __DIR__ . '/../core/security.php';
$adminData = enforceUserSecurity($pdo, 'admin');

$message = '';
$error = '';

// مفتاح التشفير الأساسي المسحوب من البيئة (يجب أن يكون معقداً في ملف .env)
$appSecret = getenv('APP_SECRET') ?: 'MGH_FALLBACK_SECRET_KEY_2026_!@#';
$encryptionKey = hash('sha256', $appSecret, true);

// دوال التشفير وفك التشفير الآمنة (AES-256-CBC)
function encryptApiKey($data, $key) {
    if (empty($data)) return null;
    $ivLength = openssl_cipher_iv_length('aes-256-cbc');
    $iv = openssl_random_pseudo_bytes($ivLength);
    $encrypted = openssl_encrypt($data, 'aes-256-cbc', $key, 0, $iv);
    return base64_encode($encrypted . '::' . $iv);
}

// معالجة طلبات الإدارة
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCSRFToken($_POST['csrf_token'] ?? '');
    $action = $_POST['action'] ?? '';

    try {
        if ($action === 'add' || $action === 'edit') {
            $prompt_name = sanitizeInput($_POST['prompt_name'] ?? '');
            $system_prompt = $_POST['system_prompt'] ?? ''; // لا نعقمه بالكامل للحفاظ على تنسيق الـ Prompt
            $api_endpoint = filter_var($_POST['api_endpoint'] ?? '', FILTER_SANITIZE_URL);
            $model_name = sanitizeInput($_POST['model_name'] ?? '');
            $raw_api_key = $_POST['api_key'] ?? '';
            
            $api_key_encrypted = null;
            if (!empty($raw_api_key)) {
                // تشفير المفتاح قبل لمس قاعدة البيانات
                $api_key_encrypted = encryptApiKey($raw_api_key, $encryptionKey);
            }

            if (empty($prompt_name) || empty($system_prompt)) {
                $error = "اسم النموذج والـ System Prompt مطلوبان.";
            } else {
                if ($action === 'add') {
                    $stmt = $pdo->prepare("INSERT INTO admin_settings_ai (prompt_name, system_prompt, api_endpoint, model_name, api_key_encrypted, is_default) VALUES (?, ?, ?, ?, ?, 0)");
                    $stmt->execute([$prompt_name, $system_prompt, $api_endpoint, $model_name, $api_key_encrypted]);
                    $message = "تمت إضافة نموذج الذكاء الاصطناعي بنجاح وتشفير المفتاح.";
                } else {
                    $id = (int)($_POST['prompt_id'] ?? 0);
                    // إذا لم يقم الأدمن بإدخال مفتاح جديد، نحافظ على القديم المشفر
                    if (!empty($raw_api_key)) {
                        $stmt = $pdo->prepare("UPDATE admin_settings_ai SET prompt_name=?, system_prompt=?, api_endpoint=?, model_name=?, api_key_encrypted=? WHERE id=?");
                        $stmt->execute([$prompt_name, $system_prompt, $api_endpoint, $model_name, $api_key_encrypted, $id]);
                    } else {
                        $stmt = $pdo->prepare("UPDATE admin_settings_ai SET prompt_name=?, system_prompt=?, api_endpoint=?, model_name=? WHERE id=?");
                        $stmt->execute([$prompt_name, $system_prompt, $api_endpoint, $model_name, $id]);
                    }
                    $message = "تم تحديث النموذج بنجاح.";
                }
            }
        } elseif ($action === 'delete') {
            $id = (int)($_POST['prompt_id'] ?? 0);
            $stmt = $pdo->prepare("DELETE FROM admin_settings_ai WHERE id=? AND is_default=0");
            $stmt->execute([$id]);
            if ($stmt->rowCount() > 0) {
                $message = "تم حذف النموذج بنجاح.";
            } else {
                $error = "لا يمكن حذف النموذج الافتراضي النشط حالياً. قم بتعيين نموذج آخر كافتراضي أولاً.";
            }
        } elseif ($action === 'set_default') {
            $id = (int)($_POST['prompt_id'] ?? 0);
            // إزالة الافتراضي من الجميع
            $pdo->query("UPDATE admin_settings_ai SET is_default = 0");
            // تعيين الجديد كافتراضي
            $stmt = $pdo->prepare("UPDATE admin_settings_ai SET is_default = 1 WHERE id=?");
            $stmt->execute([$id]);
            $message = "تم تعيين النموذج كخيار افتراضي للنظام.";
        }
    } catch (PDOException $e) {
        $error = "حدث خطأ في قاعدة البيانات.";
        error_log("Prompt Manager Error: " . $e->getMessage());
    }
}

// جلب جميع النماذج
$prompts = $pdo->query("SELECT id, prompt_name, api_endpoint, model_name, is_default, created_at FROM admin_settings_ai ORDER BY is_default DESC, id DESC")->fetchAll();
$csrfToken = generateCSRFToken();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة نماذج AI - Mugofhug</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', system-ui, sans-serif; background-color: #F8FAFC; color: #0F172A; display: flex; min-height: 100vh; }
        .sidebar { width: 250px; background-color: #1E293B; color: white; padding: 2rem 1rem; flex-shrink: 0; }
        .sidebar h2 { color: #818CF8; margin-bottom: 2rem; text-align: center; }
        .sidebar a { display: block; color: #CBD5E1; text-decoration: none; padding: 0.75rem 1rem; margin-bottom: 0.5rem; border-radius: 6px; transition: 0.3s; }
        .sidebar a:hover, .sidebar a.active { background-color: #334155; color: white; }
        .main-content { flex: 1; padding: 2rem; overflow-y: auto; }
        h1 { margin-bottom: 1.5rem; color: #1E293B; }
        
        .alert { padding: 1rem; border-radius: 6px; margin-bottom: 1.5rem; font-weight: bold; }
        .alert.success { background-color: #D1FAE5; color: #065F46; border: 1px solid #34D399; }
        .alert.error { background-color: #FEE2E2; color: #991B1B; border: 1px solid #F87171; }
        
        .form-card { background: white; padding: 1.5rem; border-radius: 8px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); margin-bottom: 2rem; border: 1px solid #E2E8F0; }
        .form-group { margin-bottom: 1rem; }
        label { display: block; margin-bottom: 0.5rem; font-weight: 600; font-size: 0.9rem; }
        input[type="text"], input[type="url"], input[type="password"], textarea { width: 100%; padding: 0.75rem; border: 1px solid #CBD5E1; border-radius: 6px; outline: none; font-family: monospace; }
        input:focus, textarea:focus { border-color: #4338CA; }
        textarea { resize: vertical; min-height: 150px; }
        .btn-submit { background-color: #4338CA; color: white; padding: 0.75rem 1.5rem; border: none; border-radius: 6px; font-weight: bold; cursor: pointer; transition: 0.2s; }
        .btn-submit:hover { background-color: #3730A3; }

        table { width: 100%; background: white; border-collapse: collapse; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        th, td { padding: 1rem; text-align: right; border-bottom: 1px solid #E2E8F0; }
        th { background-color: #F1F5F9; font-weight: 600; }
        .badge-default { background-color: #4338CA; color: white; padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.8rem; }
        
        .action-form { display: inline-block; margin-left: 0.5rem; }
        .btn-sm { padding: 0.4rem 0.8rem; border: none; border-radius: 4px; cursor: pointer; font-size: 0.85rem; font-weight: bold; color: white; }
        .btn-default { background-color: #10B981; }
        .btn-delete { background-color: #EF4444; }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>Mugofhug AI</h2>
        <a href="index.php">لوحة القيادة</a>
        <a href="users_manager.php">إدارة المستخدمين</a>
        <a href="prompts_manager.php" class="active">إعدادات الذكاء الاصطناعي</a>
    </div>
    
    <div class="main-content">
        <h1>إدارة الموجهات ومزودات الـ AI</h1>
        
        <?php if ($message): ?><div class="alert success"><?php echo htmlspecialchars($message); ?></div><?php endif; ?>
        <?php if ($error): ?><div class="alert error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

        <div class="form-card">
            <h3>إضافة نموذج / Prompt جديد</h3>
            <p style="font-size: 0.85rem; color: #64748B; margin-bottom: 1rem;">ملاحظة: سيتم تشفير مفتاح الـ API فور حفظه ولن يتم عرضه مجدداً لأسباب أمنية.</p>
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
                <input type="hidden" name="action" value="add">
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                    <div class="form-group">
                        <label>اسم النموذج (يظهر للمستخدمين)</label>
                        <input type="text" name="prompt_name" placeholder="مثال: Mugofhug Default Core" required>
                    </div>
                    <div class="form-group">
                        <label>الموديل (Model Name)</label>
                        <input type="text" name="model_name" placeholder="مثال: moonshotai/kimi-k2.5">
                    </div>
                </div>

                <div class="form-group">
                    <label>الرابط المصدري (API Endpoint)</label>
                    <input type="url" name="api_endpoint" placeholder="https://integrate.api.nvidia.com/v1/chat/completions">
                </div>

                <div class="form-group">
                    <label>مفتاح الـ API (سيتم تشفيره بـ AES-256)</label>
                    <input type="password" name="api_key" placeholder="اتركه فارغاً إذا كنت لا تريد تغييره">
                </div>

                <div class="form-group">
                    <label>النص التوجيهي (System Prompt)</label>
                    <textarea name="system_prompt" required placeholder="*** SYSTEM OVERRIDE: MUGOFHUG OMNI-CORE PRIME DIRECTIVE ***..."></textarea>
                </div>

                <button type="submit" class="btn-submit">حفظ الإعدادات بأمان</button>
            </form>
        </div>

        <table>
            <thead>
                <tr>
                    <th>اسم النموذج</th>
                    <th>الموديل</th>
                    <th>حالة الافتراضي</th>
                    <th>الإجراءات</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($prompts as $p): ?>
                <tr>
                    <td><strong><?php echo htmlspecialchars($p['prompt_name']); ?></strong></td>
                    <td><code style="background: #F1F5F9; padding: 0.2rem 0.5rem; border-radius: 4px;"><?php echo htmlspecialchars($p['model_name']); ?></code></td>
                    <td>
                        <?php if ($p['is_default']): ?>
                            <span class="badge-default">الأساسي (مفعل)</span>
                        <?php else: ?>
                            <span style="color: #64748B;">ثانوي</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if (!$p['is_default']): ?>
                        <form method="POST" class="action-form">
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
                            <input type="hidden" name="action" value="set_default">
                            <input type="hidden" name="prompt_id" value="<?php echo $p['id']; ?>">
                            <button type="submit" class="btn-sm btn-default">تعيين كافتراضي</button>
                        </form>

                        <form method="POST" class="action-form" onsubmit="return confirm('تأكيد مسح النموذج؟');">
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="prompt_id" value="<?php echo $p['id']; ?>">
                            <button type="submit" class="btn-sm btn-delete">حذف</button>
                        </form>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>