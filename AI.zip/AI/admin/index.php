<?php
// SERIAL: MGH-ADM-IDX-008

require_once __DIR__ . '/../core/security.php';

// 1. تفعيل الحماية الصارمة وإجبار التحقق من صلاحية الأدمن
$adminData = enforceUserSecurity($pdo, 'admin');

// 2. جلب الإحصائيات الحية من الجداول المرفقة بـ _ai
$stats = [
    'total_users' => 0,
    'pending_users' => 0,
    'total_files' => 0,
    'active_prompts' => 0
];

try {
    $stats['total_users'] = $pdo->query("SELECT COUNT(*) FROM users_ai")->fetchColumn();
    $stats['pending_users'] = $pdo->query("SELECT COUNT(*) FROM users_ai WHERE status = 'inactive'")->fetchColumn();
    $stats['total_files'] = $pdo->query("SELECT COUNT(*) FROM files_ai")->fetchColumn();
    $stats['active_prompts'] = $pdo->query("SELECT COUNT(*) FROM admin_settings_ai")->fetchColumn();
} catch (PDOException $e) {
    error_log("Stats Error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لوحة التحكم - Mugofhug Admin</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', system-ui, sans-serif; background-color: #F8FAFC; color: #0F172A; display: flex; }
        .sidebar { width: 250px; background-color: #1E293B; color: white; min-height: 100vh; padding: 2rem 1rem; }
        .sidebar h2 { color: #818CF8; margin-bottom: 2rem; text-align: center; font-size: 1.5rem; }
        .sidebar a { display: block; color: #CBD5E1; text-decoration: none; padding: 0.75rem 1rem; margin-bottom: 0.5rem; border-radius: 6px; transition: 0.3s; }
        .sidebar a:hover, .sidebar a.active { background-color: #334155; color: white; }
        .main-content { flex: 1; padding: 2rem; }
        .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem; padding-bottom: 1rem; border-bottom: 1px solid #E2E8F0; }
        .grid-stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1.5rem; }
        .stat-card { background: white; padding: 1.5rem; border-radius: 12px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); border: 1px solid #E2E8F0; }
        .stat-card h3 { font-size: 0.9rem; color: #64748B; margin-bottom: 0.5rem; }
        .stat-card .value { font-size: 2rem; font-weight: bold; color: #4338CA; }
        .danger-text { color: #E11D48 !important; }
        .btn-logout { background-color: #E11D48; color: white; padding: 0.5rem 1rem; text-decoration: none; border-radius: 6px; font-weight: bold; font-size: 0.9rem; }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>Mugofhug AI</h2>
        <a href="index.php" class="active">لوحة القيادة</a>
        <a href="users_manager.php">إدارة المستخدمين</a>
        <a href="prompts_manager.php">إعدادات الذكاء الاصطناعي</a>
        <a href="system_logs.php">سجلات التدقيق (Logs)</a>
    </div>
    
    <div class="main-content">
        <div class="header">
            <h1>نظرة عامة على النظام</h1>
            <div>
                مرحباً بك، <strong><?php echo htmlspecialchars($adminData['name'] ?? 'Admin'); ?></strong>
                <a href="../public/logout.php" class="btn-logout" style="margin-right: 1rem;">تسجيل خروج</a>
            </div>
        </div>

        <div class="grid-stats">
            <div class="stat-card">
                <h3>إجمالي المستخدمين</h3>
                <div class="value"><?php echo $stats['total_users']; ?></div>
            </div>
            <div class="stat-card">
                <h3>طلبات تسجيل معلقة</h3>
                <div class="value <?php echo $stats['pending_users'] > 0 ? 'danger-text' : ''; ?>">
                    <?php echo $stats['pending_users']; ?>
                </div>
            </div>
            <div class="stat-card">
                <h3>الملفات المعالجة (AI)</h3>
                <div class="value"><?php echo $stats['total_files']; ?></div>
            </div>
            <div class="stat-card">
                <h3>نماذج الـ Prompts</h3>
                <div class="value"><?php echo $stats['active_prompts']; ?></div>
            </div>
        </div>
    </div>
</body>
</html>