<?php
// SERIAL: MGH-ADM-LOG-014

require_once __DIR__ . '/../core/security.php';
$adminData = enforceUserSecurity($pdo, 'admin');

// جلب السجلات مع ربطها بأسماء المديرين والمستخدمين
$stmt = $pdo->query("
    SELECT 
        l.id, 
        l.action_type, 
        l.ip_address, 
        l.created_at,
        a.name AS admin_name,
        u.username AS target_username
    FROM audit_logs_ai l
    LEFT JOIN users_ai a ON l.admin_id = a.id
    LEFT JOIN users_ai u ON l.target_user_id = u.id
    ORDER BY l.created_at DESC
    LIMIT 200
");
$logs = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>سجلات النظام - Mugofhug Admin</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', system-ui, sans-serif; background-color: #F8FAFC; color: #0F172A; display: flex; min-height: 100vh; }
        .sidebar { width: 250px; background-color: #1E293B; color: white; padding: 2rem 1rem; flex-shrink: 0; }
        .sidebar h2 { color: #818CF8; margin-bottom: 2rem; text-align: center; }
        .sidebar a { display: block; color: #CBD5E1; text-decoration: none; padding: 0.75rem 1rem; margin-bottom: 0.5rem; border-radius: 6px; transition: 0.3s; }
        .sidebar a:hover, .sidebar a.active { background-color: #334155; color: white; }
        .main-content { flex: 1; padding: 2rem; overflow-y: auto; }
        h1 { margin-bottom: 1.5rem; color: #1E293B; }
        
        table { width: 100%; background: white; border-collapse: collapse; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); font-size: 0.95rem; }
        th, td { padding: 1rem; text-align: right; border-bottom: 1px solid #E2E8F0; }
        th { background-color: #F1F5F9; font-weight: 600; color: #475569; }
        tr:hover { background-color: #F8FAFC; }
        .badge { padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.8rem; font-weight: bold; }
        .bg-activate { background-color: #D1FAE5; color: #065F46; }
        .bg-block { background-color: #FEF3C7; color: #92400E; }
        .bg-delete { background-color: #FEE2E2; color: #991B1B; }
        .bg-default { background-color: #DBEAFE; color: #1E40AF; }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>Mugofhug AI</h2>
        <a href="index.php">لوحة القيادة</a>
        <a href="users_manager.php">إدارة المستخدمين</a>
        <a href="prompts_manager.php">إعدادات الذكاء الاصطناعي</a>
        <a href="system_logs.php" class="active">سجلات التدقيق (Logs)</a>
        <a href="code_editor.php">محرر الأكواد للملفات</a>
    </div>
    
    <div class="main-content">
        <h1>سجلات التدقيق الأمني (Audit Logs)</h1>
        <p style="margin-bottom: 2rem; color: #64748B;">يعرض هذا السجل أحدث 200 إجراء تم اتخاذه من قبل المديرين في النظام.</p>
        
        <table>
            <thead>
                <tr>
                    <th>رقم العملية</th>
                    <th>بواسطة (الأدمن)</th>
                    <th>نوع الإجراء</th>
                    <th>المستخدم المستهدف</th>
                    <th>عنوان IP</th>
                    <th>التاريخ والوقت</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($logs as $log): 
                    $actionClass = 'bg-default';
                    if ($log['action_type'] === 'activate') $actionClass = 'bg-activate';
                    if ($log['action_type'] === 'block') $actionClass = 'bg-block';
                    if ($log['action_type'] === 'delete') $actionClass = 'bg-delete';
                ?>
                <tr>
                    <td>#<?php echo $log['id']; ?></td>
                    <td><strong><?php echo htmlspecialchars($log['admin_name'] ?? 'مجهول/محذوف'); ?></strong></td>
                    <td><span class="badge <?php echo $actionClass; ?>"><?php echo strtoupper(htmlspecialchars($log['action_type'])); ?></span></td>
                    <td><?php echo htmlspecialchars($log['target_username'] ?? 'غير محدد'); ?></td>
                    <td dir="ltr" style="text-align: right;"><code><?php echo htmlspecialchars($log['ip_address']); ?></code></td>
                    <td dir="ltr" style="text-align: right;"><?php echo htmlspecialchars($log['created_at']); ?></td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($logs)): ?>
                <tr><td colspan="6" style="text-align: center;">لا توجد سجلات حتى الآن.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>