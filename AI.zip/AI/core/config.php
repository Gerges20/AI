<?php
// SERIAL: MGH-CORE-CFG-001
// ملف الإعدادات الآمن (بديل جذري لملف .env للسيرفرات الصارمة)

return [
    'DB_HOST' => 'localhost',
    'DB_NAME' => 'mugofhug_GPA',
    'DB_USER' => 'mugofhug_AI',
    'DB_PASS' => 'SamsungS1!',
    'NVIDIA_API_KEY' => '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',
    'APP_SECRET' => 'Generate_A_Random_Long_String_Here_For_CSRF'
];
?>