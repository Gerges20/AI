<?php
// SERIAL: MGH-CORE-BGW-021 (Patch: Multi-Prompt Support)

require_once __DIR__ . '/db.php';
$appSecret = $envConfig['APP_SECRET'] ?? '';
$encryptionKey = hash('sha256', $appSecret, true);

function decryptApiKey($encryptedData, $key) {
    if (empty($encryptedData)) return null;
    list($encrypted, $iv) = explode('::', base64_decode($encryptedData), 2);
    return openssl_decrypt($encrypted, 'aes-256-cbc', $key, 0, $iv);
}

// سحب الملفات مع رقم الموديل (prompt_id) المضاف حديثاً
$stmtFiles = $pdo->query("SELECT id, user_id, prompt_id, original_file_path, file_type FROM files_ai WHERE processing_status = 'pending' ORDER BY created_at ASC LIMIT 4");
$pendingFiles = $stmtFiles->fetchAll();

if (empty($pendingFiles)) {
    die("Worker Status: No pending files to process.");
}

$fileIds = array_column($pendingFiles, 'id');
$placeholders = implode(',', array_fill(0, count($fileIds), '?'));
$pdo->prepare("UPDATE files_ai SET processing_status = 'processing' WHERE id IN ($placeholders)")->execute($fileIds);

$multiCurl = curl_multi_init();
$curlHandles = [];
$uploadDir = __DIR__ . '/../storage/uploads/';

foreach ($pendingFiles as $index => $file) {
    // جلب الإعدادات الخاصة بالنموذج الذي اختاره المستخدم
    $stmtSettings = $pdo->prepare("SELECT system_prompt, api_endpoint, model_name, api_key_encrypted FROM admin_settings_ai WHERE id = ?");
    $stmtSettings->execute([$file['prompt_id']]);
    $aiSettings = $stmtSettings->fetch();

    // إذا تم مسح النموذج لسبب ما، نلجأ للافتراضي
    if (!$aiSettings) {
        $aiSettings = $pdo->query("SELECT system_prompt, api_endpoint, model_name, api_key_encrypted FROM admin_settings_ai WHERE is_default = 1 LIMIT 1")->fetch();
    }

    $apiKey = decryptApiKey($aiSettings['api_key_encrypted'], $encryptionKey) ?: $envConfig['NVIDIA_API_KEY'];
    $apiUrl = $aiSettings['api_endpoint'] ?: "https://integrate.api.nvidia.com/v1/chat/completions";
    $modelName = $aiSettings['model_name'] ?: "moonshotai/kimi-k2.5";
    $systemPrompt = $aiSettings['system_prompt'];

    $filePath = $uploadDir . $file['original_file_path'];
    $base64Image = '';
    if (file_exists($filePath)) {
        $base64Image = base64_encode(file_get_contents($filePath));
    }

    $payload = [
        "model" => $modelName,
        "messages" => [
            ["role" => "user", "content" => $systemPrompt . "\n\n<img src=\"data:image/png;base64,{$base64Image}\" />"]
        ],
        "max_tokens" => 16384, "temperature" => 1.0, "stream" => false
    ];

    $ch = curl_init($apiUrl);
    curl_setopt_array($ch, [
        CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => ["Authorization: Bearer " . $apiKey, "Content-Type: application/json"],
        CURLOPT_POSTFIELDS => json_encode($payload), CURLOPT_TIMEOUT => 300
    ]);

    curl_multi_add_handle($multiCurl, $ch);
    $curlHandles[$index] = ['handle' => $ch, 'file_info' => $file];
}

$running = null;
do { curl_multi_exec($multiCurl, $running); curl_multi_select($multiCurl); } while ($running > 0);

foreach ($curlHandles as $data) {
    $ch = $data['handle']; $fileInfo = $data['file_info'];
    $response = curl_multi_getcontent($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $status = 'failed'; $generatedHtml = '';

    if ($httpCode == 200) {
        $decoded = json_decode($response, true);
        $generatedHtml = $decoded['choices'][0]['message']['content'] ?? '';
        if (!empty($generatedHtml)) $status = 'completed';
    }
    
    $pdo->prepare("UPDATE files_ai SET processing_status = ? WHERE id = ?")->execute([$status, $fileInfo['id']]);
    if ($status === 'completed') {
        $pdo->prepare("INSERT INTO pages_ai (file_id, generated_html) VALUES (?, ?)")->execute([$fileInfo['id'], $generatedHtml]);
    }
    curl_multi_remove_handle($multiCurl, $ch); curl_close($ch);
}
curl_multi_close($multiCurl);
echo "Processed " . count($pendingFiles) . " files.\n";
?>