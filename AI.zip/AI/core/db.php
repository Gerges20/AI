<?php
// SERIAL: MGH-CORE-DB-001-V3 (Ultimate Fix)

// 1. بدء جلسة محمية
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 86400,
        'path' => '/',
        'domain' => $_SERVER['HTTP_HOST'] ?? 'localhost',
        'secure' => isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on',
        'httponly' => true,
        'samesite' => 'Strict'
    ]);
    session_start();
}

// 2. تحميل الإعدادات من ملف الـ PHP الآمن
$configPath = __DIR__ . '/config.php';

if (!file_exists($configPath)) {
    die("System Error: Critical configuration file (config.php) is missing inside the core directory.");
}

$envConfig = require $configPath;

$db_host = $envConfig['DB_HOST'] ?? 'localhost';
$db_name = $envConfig['DB_NAME'] ?? '';
$db_user = $envConfig['DB_USER'] ?? '';
$db_pass = $envConfig['DB_PASS'] ?? '';

// 3. تأسيس الاتصال بقاعدة البيانات
try {
    $pdo = new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8mb4", $db_user, $db_pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
} catch (PDOException $e) {
    // تركنا طباعة الخطأ مفعلة هنا لنتأكد من نجاحك في الاتصال
    die("Database Connection Error: " . $e->getMessage());
}
?>