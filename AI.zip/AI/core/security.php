<?php
// SERIAL: MGH-CORE-SEC-002-V2 (Patch: Data Visibility Fix)

require_once __DIR__ . '/db.php';

// 1. توليد CSRF Token
function generateCSRFToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

// 2. التحقق من CSRF Token
function verifyCSRFToken($token) {
    if (!isset($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
        die("Security Violation: CSRF Token Validation Failed.");
    }
}

// 3. تعقيم المدخلات (Sanitization)
function sanitizeInput($data) {
    return htmlspecialchars(strip_tags(trim($data)), ENT_QUOTES, 'UTF-8');
}

// 4. التحقق من صلاحيات وتفعيل المستخدم
function enforceUserSecurity($pdo, $requiredRole = null) {
    if (!isset($_SESSION['user_id'])) {
        header("Location: ../public/login.php");
        exit;
    }

    // [التصحيح الجذري]: جلب الـ id والـ name لربط الملفات بصاحبها بدقة
    $stmt = $pdo->prepare("SELECT id, name, username, role, status FROM users_ai WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();

    if (!$user) {
        session_destroy();
        header("Location: ../public/login.php?error=invalid_account");
        exit;
    }

    if ($user['status'] !== 'active') {
        session_destroy();
        die("Access Denied: Your account is " . htmlspecialchars($user['status']) . ". Contact Administrator.");
    }

    if ($requiredRole && $user['role'] !== $requiredRole) {
        die("Access Denied: Insufficient permissions.");
    }

    return $user;
}
?>