<?php
// SERIAL: MGH-CORE-AI-003

require_once __DIR__ . '/db.php';

class AIProcessor {
    private $pdo;
    private $apiKey;
    private $apiUrl;
    private $modelName;
    private $systemPrompt;

    public function __construct($pdo) {
        $this->pdo = $pdo;
        $this->loadSettings();
    }

    private function loadSettings() {
        // سحب الإعدادات الافتراضية والمشفرة من قاعدة البيانات
        $stmt = $this->pdo->prepare("SELECT system_prompt, api_endpoint, model_name, api_key_encrypted FROM admin_settings_ai WHERE is_default = 1 LIMIT 1");
        $stmt->execute();
        $settings = $stmt->fetch();

        if (!$settings) {
            throw new Exception("Critical Error: No default AI settings configured.");
        }

        $this->systemPrompt = $settings['system_prompt'];
        $this->apiUrl = $settings['api_endpoint'] ?: "https://integrate.api.nvidia.com/v1/chat/completions";
        $this->modelName = $settings['model_name'] ?: "moonshotai/kimi-k2.5";
        
        // المفتاح السري مسحوب من البيئة أو من التشفير
        $this->apiKey = getenv('NVIDIA_API_KEY'); 
    }

    // معالجة متوازية لـ 4 ملفات (Images/Base64)
    public function processFilesParallel(array $imagesBase64) {
        $multiCurl = curl_multi_init();
        $curlHandles = [];
        $results = [];

        foreach ($imagesBase64 as $index => $base64) {
            $ch = curl_init($this->apiUrl);
            
            $payload = [
                "model" => $this->modelName,
                "messages" => [
                    [
                        "role" => "user",
                        "content" => $this->systemPrompt . "\n\n<img src=\"data:image/png;base64,{$base64}\" />"
                    ]
                ],
                "max_tokens" => 16384,
                "temperature" => 1.0,
                "top_p" => 1.0,
                "stream" => false // نجبره على إرسال الرد كاملاً لتسهيل المعالجة بالخلفية
            ];

            curl_setopt_array($ch, [
                CURLOPT_POST => true,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_HTTPHEADER => [
                    "Authorization: Bearer " . $this->apiKey,
                    "Content-Type: application/json",
                    "Accept: application/json"
                ],
                CURLOPT_POSTFIELDS => json_encode($payload),
                CURLOPT_TIMEOUT => 300 // وقت كافٍ لمعالجة الكود
            ]);

            curl_multi_add_handle($multiCurl, $ch);
            $curlHandles[$index] = $ch;
        }

        // تنفيذ الطلبات بالتوازي (Parallel Execution)
        $running = null;
        do {
            curl_multi_exec($multiCurl, $running);
            curl_multi_select($multiCurl);
        } while ($running > 0);

        // جمع النتائج
        foreach ($curlHandles as $index => $ch) {
            $response = curl_multi_getcontent($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            
            if ($httpCode == 200) {
                $decodedResponse = json_decode($response, true);
                $results[$index] = $decodedResponse['choices'][0]['message']['content'] ?? false;
            } else {
                $results[$index] = false; // فشل معالجة هذا الملف
            }
            curl_multi_remove_handle($multiCurl, $ch);
            curl_close($ch);
        }

        curl_multi_close($multiCurl);
        return $results;
    }
}
?>