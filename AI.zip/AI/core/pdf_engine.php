<?php
// SERIAL: MGH-CORE-PDF-017

require_once __DIR__ . '/db.php';

function exportHtmlToSinglePagePdf($pdo, $pageId, $userId) {
    // 1. التحقق من ملكية الصفحة
    $stmt = $pdo->prepare("
        SELECT p.generated_html, f.original_file_path 
        FROM pages_ai p 
        JOIN files_ai f ON p.file_id = f.id 
        WHERE p.id = ? AND f.user_id = ?
    ");
    $stmt->execute([$pageId, $userId]);
    $page = $stmt->fetch();

    if (!$page) {
        return ['success' => false, 'error' => 'File not found or unauthorized access.'];
    }

    $rawHtml = $page['generated_html'];

    // 2. الحقن الإجباري للـ CSS (The Forced Single Page Protocol)
    // هذا الكود يمنع تقسيم العناصر ويصغر حجم المحتوى ليتسع في صفحة واحدة
    $strictCssInjector = '
    <style>
        @media print {
            * {
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
                color-adjust: exact !important;
            }
            @page {
                size: A3 portrait; /* استخدام مقاس كبير لاستيعاب المحتوى */
                margin: 0 !important;
            }
            body {
                width: 100%;
                height: 100%;
                margin: 0;
                padding: 10mm;
                /* تقنية Zoom لتصغير المحتوى وإجباره على صفحة واحدة */
                zoom: 0.65; 
            }
            /* منع كسر الصفحات قطعياً */
            div, p, h1, h2, h3, img, table, .data-node, .data-card, .mgh-callout {
                page-break-inside: avoid !important;
                break-inside: avoid !important;
                page-break-before: auto !important;
                page-break-after: auto !important;
            }
        }
    </style>
    </head>';

    // دمج الستايل الصارم مع كود الـ HTML المولد من الذكاء الاصطناعي
    $optimizedHtml = str_replace('</head>', $strictCssInjector, $rawHtml);

    /*
     * 3. ملاحظة هندسية للتحويل (PDF Conversion Execution):
     * لتوليد ملف الـ PDF فعلياً في السيرفر، يجب استخدام مكتبة مثل DomPDF.
     * مثال لكيفية التنفيذ إذا قمت بتثبيت المكتبة عبر Composer:
     * * require_once __DIR__ . '/../vendor/autoload.php';
     * use Dompdf\Dompdf;
     * use Dompdf\Options;
     * * $options = new Options();
     * $options->set('isRemoteEnabled', true);
     * $options->set('isHtml5ParserEnabled', true);
     * $dompdf = new Dompdf($options);
     * * $dompdf->loadHtml($optimizedHtml);
     * $dompdf->setPaper('A3', 'portrait');
     * $dompdf->render();
     * $pdfOutput = $dompdf->output();
     * * // حفظ الملف
     * $pdfFileName = 'final_doc_' . time() . '.pdf';
     * $pdfPath = __DIR__ . '/../storage/final_pdfs/' . $pdfFileName;
     * file_put_contents($pdfPath, $pdfOutput);
     * * // تحديث قاعدة البيانات
     * $pdo->prepare("UPDATE pages_ai SET final_pdf_path = ? WHERE id = ?")->execute([$pdfFileName, $pageId]);
     */

    // نعيد كود الـ HTML المحسن جاهزاً للطباعة المباشرة من المتصفح كبديل سريع
    return [
        'success' => true,
        'optimized_html' => $optimizedHtml,
        'message' => 'Ready for single-page print.'
    ];
}
?>