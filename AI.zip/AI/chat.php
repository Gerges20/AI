<?php
/* SERIAL_NUMBER: MGH-V1-2026-X99-PRO */

/**
 * Mugofhug Elite Architecture Unit - Ultimate Chatbot Engine
 * Full-Stack, UI/UX, and Cybersecurity optimized.
 */

// إعدادات الـ API من ملف api.txt
$api_key = "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"; // [cite: 2]
$invoke_url = "https://integrate.api.nvidia.com/v1/chat/completions"; // [cite: 1]

// معالجة طلب الدردشة (AJAX)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['message'])) {
    header('Content-Type: application/json');
    
    $user_message = $_POST['message'];
    
    $payload = [
        "model" => "moonshotai/kimi-k2.5", // [cite: 3]
        "messages" => [
            [
                "role" => "system",
                "content" => "You are the Mugofhug Elite Architecture Unit. Senior UI/UX, Full-Stack, SEO, and Cybersecurity Expert. 20+ years experience. No errors. Zero omission rule." // [cite: 3-11]
            ],
            ["role" => "user", "content" => $user_message]
        ],
        "temperature" => 1.0,
        "top_p" => 1.0,
        "max_tokens" => 4096
    ];

    $ch = curl_init($invoke_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Bearer $api_key", // [cite: 2]
        "Content-Type: application/json",
        "Accept: application/json"
    ]);

    $response = curl_exec($ch);
    if (curl_errno($ch)) {
        echo json_encode(['error' => curl_error($ch)]);
    } else {
        $result = json_decode($response, true);
        echo json_encode(['reply' => $result['choices'][0]['message']['content'] ?? 'Error in API response']);
    }
    curl_close($ch);
    exit;
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"> <title>Mugofhug - Ultimate Chat Engine</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;800&family=Tajawal:wght@400;700;800&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --mgh-primary: #4338CA;
            --mgh-bg: #F8FAFC;
            --mgh-surface: rgba(255, 255, 255, 0.75);
            --mgh-text: #0F172A;
            --mgh-text-muted: #475569;
            --mgh-border: rgba(226, 232, 240, 0.9);
            --mgh-accent-cyan: #06B6D4;
            --glass-border: 1px solid rgba(255, 255, 255, 0.6);
        } /*  */

        * { margin: 0; padding: 0; box-sizing: border-box; } /* [cite: 20] */

        body {
            font-family: 'Plus Jakarta Sans', 'Tajawal', sans-serif;
            background-color: var(--mgh-bg);
            color: var(--mgh-text);
            overflow-x: hidden;
            min-height: 100vh;
        }

        /* Ambient Background [cite: 30-31] */
        .ambient-bg {
            position: fixed;
            top: 0; left: 0; width: 100%; height: 100%;
            z-index: -1;
            overflow: hidden;
        }
        .orb {
            position: absolute;
            filter: blur(100px);
            border-radius: 50%;
            opacity: 0.5;
            animation: float 20s infinite alternate;
        }
        .orb-1 { width: 400px; height: 400px; background: var(--mgh-accent-cyan); top: -10%; left: -10%; }
        .orb-2 { width: 500px; height: 500px; background: var(--mgh-primary); bottom: -10%; right: -10%; }

        @keyframes float {
            from { transform: translate(0, 0); }
            to { transform: translate(50px, 50px); }
        }

        /* Header & Glassmorphism [cite: 32] */
        header {
            backdrop-filter: blur(24px);
            background: rgba(255, 255, 255, 0.1);
            border-bottom: var(--glass-border);
            padding: 1rem;
            text-align: center;
            position: sticky;
            top: 0;
            z-index: 100;
        }
        .brand-pill {
            background: var(--mgh-primary);
            color: white;
            padding: 4px 16px;
            border-radius: 20px;
            font-weight: 800;
            display: inline-block;
            font-size: 0.9rem;
        }

        /* Chat Container [cite: 34-36] */
        .chat-container {
            max-width: 800px;
            margin: 2rem auto;
            padding: 0 1rem;
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
        }
        .data-card {
            backdrop-filter: blur(20px);
            background: var(--mgh-surface);
            border: var(--glass-border);
            padding: 1.5rem;
            border-radius: 24px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.05);
            transition: transform 0.3s ease;
        }
        .data-card:hover { transform: translateY(-5px); }

        .input-area {
            position: fixed;
            bottom: 2rem;
            left: 50%;
            transform: translateX(-50%);
            width: 90%;
            max-width: 700px;
            display: flex;
            gap: 10px;
            background: rgba(255,255,255,0.8);
            padding: 10px;
            border-radius: 50px;
            border: var(--glass-border);
            backdrop-filter: blur(10px);
        }
        input {
            flex: 1;
            border: none;
            background: transparent;
            padding: 10px 20px;
            font-size: clamp(0.9rem, 2vw, 1.1rem); /* [cite: 28] */
            outline: none;
        }
        button {
            background: var(--mgh-primary);
            color: white;
            border: none;
            padding: 10px 25px;
            border-radius: 30px;
            cursor: pointer;
            font-weight: 600;
        }

        /* Print Settings [cite: 21-24] */
        @media print {
            * { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
            @page { size: auto; margin: 10mm; }
            .input-area, .ambient-bg { display: none; }
            .data-card { break-inside: avoid; border: 1px solid #000; }
        }

        /* Mobile View [cite: 28] */
        @media (max-width: 768px) {
            .chat-container { margin: 1rem auto; }
        }
    </style>
</head>
<body>

    <div class="ambient-bg">
        <div class="orb orb-1"></div>
        <div class="orb orb-2"></div>
    </div>

    <header>
        <div class="brand-pill">Mugofhug Omni-Core</div>
    </header>

    <div class="chat-container" id="chat-box">
        <div class="data-card">
            <strong>النظام:</strong> مرحباً بك في وحدة هندسة Mugofhug النخبة. كيف يمكنني مساعدتك اليوم؟
        </div>
    </div>

    <form class="input-area" id="chat-form">
        <input type="text" id="user-input" placeholder="اكتب سؤالك هنا..." required>
        <button type="submit">إرسال</button>
    </form>

    <script>
        const chatForm = document.getElementById('chat-form');
        const chatBox = document.getElementById('chat-box');
        const userInput = document.getElementById('user-input');

        chatForm.onsubmit = async (e) => {
            e.preventDefault();
            const msg = userInput.value;
            if(!msg) return;

            // إضافة رسالة المستخدم للواجهة
            appendMessage('أنت', msg);
            userInput.value = '';

            try {
                const response = await fetch('', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `message=${encodeURIComponent(msg)}`
                });
                const data = await response.json();
                appendMessage('Mugofhug AI', data.reply);
            } catch (error) {
                appendMessage('Error', 'فشل الاتصال بالخادم.');
            }
        };

        function appendMessage(sender, text) {
            const div = document.createElement('div');
            div.className = 'data-card';
            div.innerHTML = `<strong>${sender}:</strong> <p>${text}</p>`;
            chatBox.appendChild(div);
            window.scrollTo(0, document.body.scrollHeight);
        }
    </script>
</body>
</html>