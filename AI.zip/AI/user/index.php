<?php
// SERIAL: MGH-USR-IDX-020 (Patch: 500 Error Fix & AI Selector)

require_once __DIR__ . '/../core/security.php';
$userData = enforceUserSecurity($pdo, 'user');

$message = '';
$error = '';

// [تصحيح صامت]: إضافة عمود prompt_id لقاعدة البيانات تلقائياً إذا لم يكن موجوداً
try {
    $pdo->exec("ALTER TABLE files_ai ADD COLUMN prompt_id INT DEFAULT NULL AFTER user_id");
} catch (PDOException $e) {
    // نتجاهل الخطأ إذا كان العمود موجوداً بالفعل
}

// جلب نماذج الـ AI المتاحة ليختار منها المستخدم
$promptsStmt = $pdo->query("SELECT id, prompt_name, is_default FROM admin_settings_ai ORDER BY is_default DESC, id DESC");
$availablePrompts = $promptsStmt->fetchAll();

// معالجة الرفع
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCSRFToken($_POST['csrf_token'] ?? '');
    
    if (isset($_FILES['document']) && $_FILES['document']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['document']['tmp_name'];
        $fileName = $_FILES['document']['name'];
        $fileSize = $_FILES['document']['size'];
        $selectedPromptId = (int)($_POST['prompt_id'] ?? 0);
        
        $maxFileSize = 5 * 1024 * 1024; // 5MB
        
        // [حل الخطأ 500]: استخدام دالة متوافقة مع خوادم LiteSpeed
        $actualMimeType = $_FILES['document']['type']; 
        if (function_exists('mime_content_type')) {
            $actualMimeType = @mime_content_type($fileTmpPath) ?: $actualMimeType;
        }

        $allowedMimeTypes = ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'];

        if ($fileSize > $maxFileSize) {
            $error = "حجم الملف يتجاوز الحد الأقصى المسموح به (5MB).";
        } elseif (!in_array($actualMimeType, $allowedMimeTypes)) {
            $error = "نوع الملف غير مدعوم. يرجى رفع صورة (JPG, PNG, WEBP) أو ملف PDF.";
        } else {
            $uploadDir = __DIR__ . '/../storage/uploads/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }
            
            $newFileName = bin2hex(random_bytes(16)) . '_' . time() . '.' . pathinfo($fileName, PATHINFO_EXTENSION);
            $destination = $uploadDir . $newFileName;
            
            if (move_uploaded_file($fileTmpPath, $destination)) {
                try {
                    // إدراج الملف مع رقم الموديل الذي اختاره المستخدم
                    $stmt = $pdo->prepare("INSERT INTO files_ai (user_id, prompt_id, original_file_path, file_type, file_size_bytes, processing_status) VALUES (?, ?, ?, ?, ?, 'pending')");
                    $stmt->execute([$userData['id'], $selectedPromptId, $newFileName, $actualMimeType, $fileSize]);
                    $message = "تم استلام الملف بنجاح وإدراجه في طابور الذكاء الاصطناعي.";
                } catch (PDOException $e) {
                    $error = "حدث خطأ أثناء تسجيل الملف.";
                }
            } else {
                $error = "فشل في حفظ الملف على السيرفر (تأكد من تصاريح المجلد).";
            }
        }
    } else {
        $error = "يرجى اختيار ملف صالح للرفع.";
    }
}

// جلب ملفات المستخدم
$stmtFiles = $pdo->prepare("SELECT f.id, f.original_file_path, f.processing_status, f.created_at, p.id as page_id FROM files_ai f LEFT JOIN pages_ai p ON f.id = p.file_id WHERE f.user_id = ? ORDER BY f.created_at DESC");
$stmtFiles->execute([$userData['id']]);
$userFiles = $stmtFiles->fetchAll();
$csrfToken = generateCSRFToken();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>مساحة العمل - Mugofhug AI</title>
    <style>
        /* (نفس التنسيقات السابقة مع إضافة تنسيق القائمة المنسدلة) */
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', system-ui, sans-serif; background-color: #F8FAFC; color: #0F172A; }
        .navbar { background-color: #1E293B; color: white; padding: 1rem 2rem; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); }
        .navbar .brand { font-size: 1.2rem; font-weight: 800; color: #818CF8; }
        .navbar a { color: white; text-decoration: none; font-weight: bold; background: rgba(255,255,255,0.1); padding: 0.5rem 1rem; border-radius: 6px; font-size: 0.9rem; }
        .container { max-width: 1000px; margin: 2rem auto; padding: 0 1rem; }
        .upload-card { background: white; padding: 2.5rem 2rem; border-radius: 12px; box-shadow: 0 10px 15px -3px rgba(0,0,0,0.05); border: 2px dashed #CBD5E1; text-align: center; margin-bottom: 2.5rem; }
        .upload-card h2 { margin-bottom: 1rem; }
        select.prompt-select { width: 100%; max-width: 300px; padding: 0.75rem; border: 1px solid #CBD5E1; border-radius: 6px; margin-bottom: 1.5rem; font-weight: bold; font-family: inherit; outline: none; }
        input[type="file"] { display: none; }
        .custom-file-upload { display: inline-block; background-color: #4338CA; color: white; padding: 0.8rem 2rem; border-radius: 6px; cursor: pointer; font-weight: bold; }
        .btn-submit { background-color: #10B981; color: white; padding: 0.8rem 2rem; border: none; border-radius: 6px; cursor: pointer; font-weight: bold; margin-top: 1rem; width: 100%; max-width: 300px; display: none; }
        .alert { padding: 1rem; border-radius: 6px; margin-bottom: 1.5rem; font-weight: bold; text-align: center; }
        .alert.success { background-color: #D1FAE5; color: #065F46; border: 1px solid #34D399; }
        .alert.error { background-color: #FEE2E2; color: #991B1B; border: 1px solid #F87171; }
        .files-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 1.5rem; }
        .file-card { background: white; padding: 1.5rem; border-radius: 8px; border: 1px solid #E2E8F0; }
        .status { display: inline-block; padding: 0.35rem 0.75rem; border-radius: 999px; font-size: 0.8rem; font-weight: bold; margin-bottom: 1rem; }
        .st-pending { background-color: #FEF3C7; color: #92400E; }
        .st-processing { background-color: #DBEAFE; color: #1E40AF; }
        .st-completed { background-color: #D1FAE5; color: #065F46; }
        .st-failed { background-color: #FEE2E2; color: #991B1B; }
        .btn-action { display: block; text-align: center; background-color: #4338CA; color: white; text-decoration: none; padding: 0.6rem; border-radius: 6px; font-weight: bold; }
        .btn-disabled { background-color: #CBD5E1; color: #64748B; cursor: not-allowed; }
    </style>
</head>
<body>
    <div class="navbar">
        <div class="brand">Mugofhug Workspace</div>
        <div>
            <span style="margin-left: 1.5rem;">مرحباً، <?php echo htmlspecialchars($userData['name']); ?></span>
            <a href="../public/logout.php">تسجيل الخروج</a>
        </div>
    </div>

    <div class="container">
        <?php if ($message): ?><div class="alert success"><?php echo htmlspecialchars($message); ?></div><?php endif; ?>
        <?php if ($error): ?><div class="alert error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

        <div class="upload-card">
            <h2>رفع ملاحظات ومعالجتها</h2>
            <p style="color: #64748B; margin-bottom: 1rem;">اختر الموديل (AI Prompt) ثم قم برفع صورتك أو ملفك.</p>
            
            <form method="POST" enctype="multipart/form-data" id="uploadForm">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
                
                <select name="prompt_id" class="prompt-select" required>
                    <option value="" disabled selected>-- اختر نموذج المعالجة --</option>
                    <?php foreach ($availablePrompts as $prompt): ?>
                        <option value="<?php echo $prompt['id']; ?>">
                            <?php echo htmlspecialchars($prompt['prompt_name']); ?> 
                            <?php echo $prompt['is_default'] ? '(الأساسي)' : ''; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <br>

                <label class="custom-file-upload">
                    <input type="file" name="document" id="fileInput" accept="image/jpeg, image/png, image/webp, application/pdf" required>
                    اختيار ملف من جهازك
                </label>
                <div id="fileNameDisplay" style="margin-top: 1rem; font-weight: bold; color: #4338CA;"></div>
                
                <button type="submit" class="btn-submit" id="submitBtn">بدء المعالجة بالذكاء الاصطناعي</button>
            </form>
        </div>

        <div class="files-grid">
            <?php foreach ($userFiles as $file): ?>
            <div class="file-card">
                <div style="font-size: 0.8rem; color: #94A3B8; margin-bottom: 0.5rem;"><?php echo htmlspecialchars($file['created_at']); ?></div>
                <h3 style="margin-bottom: 1rem; font-size: 0.95rem; word-break: break-all;"><?php echo htmlspecialchars(basename($file['original_file_path'])); ?></h3>
                
                <?php 
                    $stClass = 'st-pending'; $stText = 'قيد الانتظار';
                    if ($file['processing_status'] === 'processing') { $stClass = 'st-processing'; $stText = 'جاري المعالجة...'; }
                    if ($file['processing_status'] === 'completed') { $stClass = 'st-completed'; $stText = 'اكتملت المعالجة'; }
                    if ($file['processing_status'] === 'failed') { $stClass = 'st-failed'; $stText = 'فشل المعالجة'; }
                ?>
                <div class="status <?php echo $stClass; ?>"><?php echo $stText; ?></div>
                
                <?php if ($file['processing_status'] === 'completed' && $file['page_id']): ?>
                    <a href="editor.php?page_id=<?php echo $file['page_id']; ?>" class="btn-action">استعراض وتعديل (Editor)</a>
                <?php else: ?>
                    <span class="btn-action btn-disabled">غير متاح حالياً</span>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <script>
        document.getElementById('fileInput').addEventListener('change', function(e) {
            var fileName = e.target.files[0].name;
            var fileSize = e.target.files[0].size;
            if (fileSize > 5 * 1024 * 1024) {
                alert('عذراً، حجم الملف يتجاوز 5 ميجابايت.');
                this.value = ''; 
                document.getElementById('submitBtn').style.display = 'none';
            } else {
                document.getElementById('fileNameDisplay').textContent = 'الملف: ' + fileName;
                document.getElementById('submitBtn').style.display = 'inline-block';
            }
        });

        document.getElementById('uploadForm').addEventListener('submit', function() {
            var btn = document.getElementById('submitBtn');
            btn.textContent = 'جاري الرفع... يرجى الانتظار';
            btn.style.backgroundColor = '#64748B';
            btn.style.pointerEvents = 'none';
        });
    </script>
</body>
</html>