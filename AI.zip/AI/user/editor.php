<?php
// SERIAL: MGH-USR-EDT-019

require_once __DIR__ . '/../core/security.php';

// التحقق من صلاحيات المستخدم
$userData = enforceUserSecurity($pdo, 'user');

$message = '';
$error = '';
$page_id = isset($_GET['page_id']) ? (int)$_GET['page_id'] : 0;

// التأكد من أن المستخدم يمتلك هذا الملف حقاً (حماية من ثغرات IDOR)
$stmt = $pdo->prepare("
    SELECT p.id, p.generated_html, f.original_file_path, f.user_id 
    FROM pages_ai p 
    JOIN files_ai f ON p.file_id = f.id 
    WHERE p.id = ? AND f.user_id = ?
");
$stmt->execute([$page_id, $userData['id']]);
$pageData = $stmt->fetch();

if (!$pageData) {
    die("Security Alert: Access denied or file not found.");
}

// معالجة طلب الحفظ عند تعديل المستخدم للملف
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'save_document') {
    verifyCSRFToken($_POST['csrf_token'] ?? '');
    $updated_html = $_POST['generated_html'] ?? '';

    if (!empty($updated_html)) {
        try {
            $updateStmt = $pdo->prepare("UPDATE pages_ai SET generated_html = ? WHERE id = ?");
            $updateStmt->execute([$updated_html, $page_id]);
            $pageData['generated_html'] = $updated_html; // تحديث المتغير للعرض المباشر
            $message = "تم حفظ التعديلات بنجاح.";
        } catch (PDOException $e) {
            $error = "حدث خطأ أثناء الحفظ.";
        }
    }
}

$csrfToken = generateCSRFToken();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>المحرر المرئي - Mugofhug AI</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', system-ui, sans-serif; background-color: #F8FAFC; color: #0F172A; display: flex; flex-direction: column; height: 100vh; overflow: hidden; }
        
        /* شريط التنقل العلوي */
        .editor-header { background-color: #1E293B; color: white; padding: 1rem 2rem; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); z-index: 10; }
        .editor-header h2 { font-size: 1.1rem; color: #818CF8; }
        .header-actions { display: flex; gap: 1rem; }
        .btn { padding: 0.5rem 1.2rem; border-radius: 6px; font-weight: bold; cursor: pointer; border: none; font-size: 0.9rem; text-decoration: none; transition: 0.2s; display: inline-flex; align-items: center; justify-content: center; }
        .btn-back { background-color: #475569; color: white; }
        .btn-back:hover { background-color: #334155; }
        .btn-save { background-color: #10B981; color: white; }
        .btn-save:hover { background-color: #059669; }
        .btn-pdf { background-color: #E11D48; color: white; }
        .btn-pdf:hover { background-color: #BE123C; }

        /* شريط أدوات التعديل (WYSIWYG Toolbar) */
        .toolbar { background-color: #FFFFFF; padding: 0.75rem 2rem; border-bottom: 1px solid #E2E8F0; display: flex; gap: 0.5rem; flex-wrap: wrap; justify-content: center; align-items: center; box-shadow: 0 2px 4px rgba(0,0,0,0.02); z-index: 5; }
        .toolbar button, .toolbar select, .toolbar input[type="color"] { padding: 0.4rem 0.8rem; border: 1px solid #CBD5E1; background: #F8FAFC; border-radius: 4px; cursor: pointer; font-size: 0.9rem; color: #334155; font-weight: 600; transition: 0.2s; }
        .toolbar button:hover, .toolbar select:hover { background: #E2E8F0; border-color: #94A3B8; }
        .toolbar-divider { width: 1px; height: 24px; background-color: #CBD5E1; margin: 0 0.5rem; }

        /* منطقة الإشعارات */
        .alert-container { position: absolute; top: 120px; left: 50%; transform: translateX(-50%); z-index: 50; width: 100%; max-width: 400px; text-align: center; }
        .alert { padding: 0.75rem; border-radius: 6px; font-weight: bold; box-shadow: 0 4px 6px rgba(0,0,0,0.1); margin-bottom: 0.5rem; }
        .alert.success { background-color: #D1FAE5; color: #065F46; border: 1px solid #34D399; }
        .alert.error { background-color: #FEE2E2; color: #991B1B; border: 1px solid #F87171; }

        /* حاوية المحرر (Iframe) */
        .editor-container { flex: 1; background-color: #E2E8F0; padding: 1.5rem; overflow: hidden; display: flex; justify-content: center; }
        .document-wrapper { background: white; width: 100%; max-width: 1200px; height: 100%; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1); border-radius: 8px; overflow: hidden; border: 1px solid #CBD5E1; }
        iframe { width: 100%; height: 100%; border: none; background-color: white; }
    </style>
</head>
<body>

    <textarea id="raw-html-content" style="display:none;"><?php echo htmlspecialchars($pageData['generated_html']); ?></textarea>

    <div class="editor-header">
        <h2>Mugofhug Studio: <?php echo htmlspecialchars(basename($pageData['original_file_path'])); ?></h2>
        <div class="header-actions">
            <a href="index.php" class="btn btn-back">رجوع للملفات</a>
            <button class="btn btn-pdf" onclick="exportToPDF()">تصدير PDF</button>
            <form method="POST" id="saveForm" style="display: inline;">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
                <input type="hidden" name="action" value="save_document">
                <input type="hidden" name="generated_html" id="html_payload">
                <button type="button" class="btn btn-save" onclick="saveDocument()">حفظ التعديلات</button>
            </form>
        </div>
    </div>

    <div class="toolbar" dir="ltr">
        <select onchange="execCmd('formatBlock', this.value)">
            <option value="">Paragraph (P)</option>
            <option value="H1">Title (H1)</option>
            <option value="H2">Subtitle (H2)</option>
            <option value="H3">Heading 3 (H3)</option>
        </select>
        <div class="toolbar-divider"></div>
        <button onclick="execCmd('bold')"><b>B</b></button>
        <button onclick="execCmd('italic')"><i>I</i></button>
        <button onclick="execCmd('underline')"><u>U</u></button>
        <button onclick="execCmd('strikeThrough')"><del>S</del></button>
        <div class="toolbar-divider"></div>
        <button onclick="execCmd('justifyLeft')">Left</button>
        <button onclick="execCmd('justifyCenter')">Center</button>
        <button onclick="execCmd('justifyRight')">Right</button>
        <div class="toolbar-divider"></div>
        <button onclick="execCmd('insertUnorderedList')">Bullet List</button>
        <button onclick="execCmd('insertOrderedList')">Number List</button>
        <div class="toolbar-divider"></div>
        <label style="font-size: 0.8rem; color:#64748B;">Text:</label>
        <input type="color" onchange="execCmd('foreColor', this.value)" title="Text Color">
        <label style="font-size: 0.8rem; color:#64748B; margin-left:5px;">Highlight:</label>
        <input type="color" onchange="execCmd('hiliteColor', this.value)" title="Background Color">
    </div>

    <div class="alert-container" id="alert-box">
        <?php if ($message): ?><div class="alert success"><?php echo htmlspecialchars($message); ?></div><?php endif; ?>
        <?php if ($error): ?><div class="alert error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
    </div>

    <div class="editor-container">
        <div class="document-wrapper">
            <iframe id="editor-iframe"></iframe>
        </div>
    </div>

    <script>
        const iframe = document.getElementById('editor-iframe');
        const rawContent = document.getElementById('raw-html-content').value;
        let editorDoc;

        // تهيئة محرك التعديل داخل الـ Iframe
        window.onload = function() {
            editorDoc = iframe.contentDocument || iframe.contentWindow.document;
            editorDoc.open();
            editorDoc.write(rawContent);
            editorDoc.close();
            
            // تفعيل خاصية التعديل الشاملة (WYSIWYG)
            editorDoc.designMode = "on";
            
            // إخفاء رسائل النظام بعد 3 ثوانٍ
            setTimeout(() => {
                const alertBox = document.getElementById('alert-box');
                if (alertBox) alertBox.style.display = 'none';
            }, 3000);
        };

        // تنفيذ أوامر شريط الأدوات
        function execCmd(command, value = null) {
            editorDoc.execCommand(command, false, value);
            iframe.contentWindow.focus();
        }

        // حفظ المستند
        function saveDocument() {
            const currentHTML = editorDoc.documentElement.outerHTML;
            document.getElementById('html_payload').value = currentHTML;
            document.getElementById('saveForm').submit();
        }

        // تصدير PDF بذكاء باستخدام إعدادات الطباعة الإجبارية
        function exportToPDF() {
            // كود الـ AI يحتوي بالفعل على @media print لمنع الكسر والتصغير (Zoom)
            // سنقوم باستدعاء أمر الطباعة الخاص بالمتصفح، والذي سيتكفل بتحويلها لـ PDF بصفحة واحدة بناءً على الكود
            iframe.contentWindow.focus();
            iframe.contentWindow.print();
        }
    </script>
</body>
</html>